"""
Application Orchestrator module.
Coordinates GUI, VLC Player, URL Resolver, ThreadPoolExecutor, History, and AutoTuner.
Strictly implements §7.6 (Re-resolve Strategy) and §9 (Threading & Anti-freeze).
Guarantees long-term stability: no freezes, no RAM leaks, no SQLite thread blocks, and auto stream recovery.
"""

import concurrent.futures
import gc
import logging
import sys
import threading
import time
import tkinter as tk
from tkinter import messagebox, filedialog
from typing import Optional, Callable, Dict, Any, Tuple

from main.constants import UI_UPDATE_INTERVAL_MS
from main.settings import SettingsManager
from main.theme import ThemeManager
from main.history import HistoryManager
from main.system_info import SystemInfo
from main.auto_tune import AutoTuner
from main.url_resolver import resolve_facebook_url, ResolverError, is_potential_video_url
from main.vlc_player import VLCPlayer, VLCPlayerError
from main.gui import MainWindow
from main.timestamp import format_timestamp

logger = logging.getLogger("FBVideoWatcher")


class Application:
    """Core application orchestrator connecting UI, threading, resolver, and VLC engine."""

    def __init__(
        self,
        root: tk.Tk,
        settings_mgr: Optional[SettingsManager] = None,
        history_mgr: Optional[HistoryManager] = None,
    ):
        self.root = root
        self._is_shutting_down = False

        # 1. Initialize Settings, Theme, and History managers
        self.settings = settings_mgr or SettingsManager()
        initial_theme = self.settings.get("ui", "theme", default="system")
        self.theme = ThemeManager(self.root, initial_theme=initial_theme)
        self.history = history_mgr or HistoryManager()

        # 2. Detect System Info & Auto-tune VLC arguments
        self.sys_info = SystemInfo.detect()
        self.tuner = AutoTuner(self.sys_info, self.settings.settings)
        self.vlc_args = self.tuner.build_vlc_args()

        if self.sys_info.is_hybrid_cpu:
            cpu_desc = f"{self.sys_info.cpu_name} ({self.sys_info.cpu_cores_physical}C: {self.sys_info.cpu_p_cores}P + {self.sys_info.cpu_e_cores}E / {self.sys_info.cpu_cores_logical}T)"
        else:
            cpu_desc = f"{self.sys_info.cpu_name} ({self.sys_info.cpu_cores_logical}T)"

        logger.info(
            f"Phần cứng: CPU={cpu_desc}, "
            f"RAM={self.sys_info.ram_total_gb:.1f}GB, GPU={self.sys_info.gpu_name}"
        )
        logger.info(f"Tham số VLC: {' '.join(self.vlc_args)}")
        self._apply_cpu_optimizations()

        # 3. Dedicated Background Worker Thread Pool (§9.2 D)
        pool_size = self.tuner.recommend_thread_pool_size()
        self.executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=pool_size,
            thread_name_prefix="fbw-worker",
        )

        # 4. State tracking for Stream Re-resolution & Stability (§7.6)
        self._original_url: Optional[str] = None
        self._current_stream_url: Optional[str] = None
        self._re_resolve_attempts = 0
        self._max_re_resolve_attempts = 3
        self._active_future: Optional[concurrent.futures.Future] = None
        self._consecutive_healthy_play_ticks = 0

        # Autosave throttling
        self._last_saved_position_ms = 0
        self._last_saved_time = 0.0

        # Loop & A-B repeat states
        self._is_loop_enabled: bool = self.settings.get("playback", "loop_enabled", default=False)
        self._ab_point_a: Optional[int] = None
        self._ab_point_b: Optional[int] = None
        self._resolved_duration_ms: int = 0

        # 5. Initialize GUI Window
        self.gui = MainWindow(
            root=self.root,
            settings_mgr=self.settings,
            theme_mgr=self.theme,
            on_play_request=self.handle_play_request,
            on_pause_toggle=self.handle_pause_toggle,
            on_seek_request=self.handle_seek_request,
            on_seek_relative=self.handle_seek_relative,
            on_volume_change=self.handle_volume_change,
            on_mute_toggle=self.handle_mute_toggle,
            on_rate_change=self.handle_rate_change,
            on_settings_saved=self.handle_settings_updated,
            on_history_request=self.handle_open_history,
            on_download_request=self.handle_download_request,
            on_loop_toggle=self.handle_loop_toggle,
            on_ab_repeat_toggle=self.handle_ab_repeat_toggle,
            on_subtitle_load=self.handle_load_subtitle,
            on_update_request=self._start_update_download,
        )
        self.gui.set_loop_state(self._is_loop_enabled)

        # 6. Initialize VLC Player embedded in video container
        try:
            self.player = VLCPlayer(self.gui.video_container, vlc_args=self.vlc_args)
            self.player.on_end_reached(self._on_playback_ended)
            self.player.on_error(self._on_playback_error)

            # Apply persistent audio volume and mute state
            init_vol = self.settings.get("audio", "default_volume", default=80)
            init_muted = self.settings.get("audio", "is_muted", default=False)
            self.player.set_volume(init_vol)
            if init_muted:
                self.player.set_mute(True)
            self.gui.volume_scale.set(init_vol)
            self.gui.set_mute_button_state(init_muted)

            # Register stream proxy in-use predicate to protect active/paused proxy streams
            try:
                from main.stream_proxy import StreamProxyServer
                StreamProxyServer.get_instance().set_in_use_predicate(
                    lambda: bool(self.player and self.player.is_proxy_active())
                )
            except Exception:
                pass
        except VLCPlayerError as exc:
            messagebox.showerror(
                "Lỗi VLC Media Player",
                f"Không thể khởi chạy VLC engine: {exc}\n"
                "Vui lòng đảm bảo đã cài đặt phần mềm VLC Media Player (64-bit).",
            )
            self.player = None

        # 7. Register Clean Shutdown protocol (§9.2 E)
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        # 8. Start periodic UI refresh timer (§9.2 C)
        self._start_ui_timer()

        # 9. Start periodic maintenance (GC & WAL checkpoint)
        self._start_maintenance_timer()

        # 10. Restore last played URL into URL entry box (§Feature 1)
        last_url = self.settings.get("playback", "last_url", default="")
        if not last_url:
            recent = self.history.get_history(limit=1)
            if recent:
                last_url = recent[0].get("url", "")

        if last_url:
            self.gui.url_entry.delete(0, tk.END)
            self.gui.url_entry.insert(0, last_url)
            self.gui.overlay_label.configure(
                text="Nhấn 'Phát' để tiếp tục xem video gần nhất"
            )

        # 11. Clipboard auto-detection
        self._last_detected_clipboard = ""
        self._active_downloader = None
        self.root.bind("<FocusIn>", self._on_window_focus_in, add="+")
        self._start_clipboard_timer()

        # 12. Check if restarting from an update with saved playback state
        from main.updater import load_and_clear_resume_state
        self._update_resume_state = load_and_clear_resume_state()
        if self._update_resume_state and self._update_resume_state.get("url"):
            self.root.after(400, self._apply_post_update_resume)

        # 13. Background check for updates (non-blocking)
        self.root.after(4000, lambda: threading.Thread(target=self._background_check_update, daemon=True).start())

    # --- Periodic UI Refresh Timer (250ms interval) ---

    def _start_ui_timer(self) -> None:
        """Schedule UI updates via root.after() instead of while-loop."""
        self._update_ui_state()

    def _update_ui_state(self) -> None:
        """Periodic tick running on main thread to synchronize UI with VLC engine."""
        if self._is_shutting_down:
            return

        if self.player:
            current_ms = self.player.get_position()
            duration_ms = self.player.get_duration()
            if duration_ms <= 0 and getattr(self, "_resolved_duration_ms", 0) > 0:
                duration_ms = self._resolved_duration_ms
            self.gui.update_playback_time(current_ms, duration_ms)

            state = self.player.state
            self.gui.set_play_pause_button_state(state == "playing")

            if state == "playing":
                self._consecutive_healthy_play_ticks += 1
                # If played continuously for >= 30 seconds after reconnect, reset retry counter
                if self._consecutive_healthy_play_ticks >= int(30000 / UI_UPDATE_INTERVAL_MS):
                    self._re_resolve_attempts = 0

                # A-B Repeat loop check: loop back to Point A when Point B is reached
                if self._ab_point_a is not None and self._ab_point_b is not None:
                    if current_ms >= self._ab_point_b or current_ms < max(0, self._ab_point_a - 1500):
                        self.player.seek_to(self._ab_point_a)

                # Throttled async position autosave: at most once every 5 seconds
                now = time.monotonic()
                if (
                    self._original_url
                    and current_ms > 5000
                    and (now - self._last_saved_time >= 5.0)
                    and abs(current_ms - self._last_saved_position_ms) >= 3000
                ):
                    self._last_saved_time = now
                    self._last_saved_position_ms = current_ms
                    # Submit to background executor to completely prevent UI thread disk I/O stalls
                    self.executor.submit(
                        self.history.update_position,
                        self._original_url,
                        current_ms,
                        duration_ms,
                    )
            else:
                self._consecutive_healthy_play_ticks = 0

        self.root.after(UI_UPDATE_INTERVAL_MS, self._update_ui_state)

    # --- Periodic Maintenance (Memory leak & WAL prevention) ---

    def _start_maintenance_timer(self) -> None:
        """Schedule 60-second periodic maintenance for long-term video stability."""
        self.root.after(60000, self._periodic_maintenance)

    def _periodic_maintenance(self) -> None:
        """Run GC and WAL checkpointing every 60s."""
        if self._is_shutting_down:
            return

        # 1. Collect cyclic garbage in Python heap
        gc.collect(1)

        # 2. Checkpoint SQLite WAL in background
        self.executor.submit(self.history.checkpoint_wal)

        # Re-arm timer
        self.root.after(60000, self._periodic_maintenance)

    def _start_clipboard_timer(self) -> None:
        """Schedule periodic clipboard check (every 1000ms)."""
        self.root.after(1000, self._periodic_clipboard_check)

    def _periodic_clipboard_check(self) -> None:
        """Periodic tick checking clipboard for copied video links."""
        if self._is_shutting_down:
            return
        self._check_clipboard()
        self.root.after(1000, self._periodic_clipboard_check)

    # --- Playback & Action Handlers ---

    def handle_play_request(self, url: str) -> None:
        """Handle URL play request from user (resolves via background thread)."""
        if not self.player:
            messagebox.showwarning("VLC chưa sẵn sàng", "VLC engine chưa khởi động được.")
            return

        # Save previous video position before loading new one (§7.2 case #17)
        if self._original_url:
            self._save_current_position()

        self._original_url = url
        self._re_resolve_attempts = 0
        self._consecutive_healthy_play_ticks = 0
        self._ab_point_a = None
        self._ab_point_b = None
        if hasattr(self.gui, "set_ab_repeat_state"):
            self.gui.set_ab_repeat_state("OFF")
        self.settings.set("playback", "last_url", url)
        self.settings.save()
        logger.info(f"Nhận yêu cầu phát URL: {url}")

        # Update GUI to loading state
        self.gui.set_loading("Đang phân giải liên kết video...")
        self.gui.set_status("Đang lấy luồng video qua yt-dlp...")

        # Cancel any previous in-flight resolve task (§7.2 case #16)
        if self._active_future and not self._active_future.done():
            self._active_future.cancel()

        cookie_file = self.settings.get("advanced", "cookie_file", default="")
        max_height = self.settings.get("video", "max_height", default=1080)

        # Submit resolution task to background thread pool
        future = self.executor.submit(
            resolve_facebook_url,
            url=url,
            cookie_file=cookie_file if cookie_file else None,
            max_height=max_height,
        )
        self._active_future = future
        future.add_done_callback(
            lambda f: self.root.after(0, lambda: self._on_resolve_completed(f, url))
        )

    def _on_resolve_completed(self, future: concurrent.futures.Future, original_url: str) -> None:
        """Callback invoked on Main Thread when resolution completes."""
        if self._is_shutting_down:
            return

        try:
            resolved = future.result()
        except concurrent.futures.CancelledError:
            return
        except ResolverError as err:
            logger.warning(f"Lỗi phân giải URL: {err}")
            self.gui.show_error(str(err))
            return
        except Exception as exc:
            logger.error(f"Lỗi không xác định khi phân giải: {exc}")
            self.gui.show_error(f"Lỗi không xác định: {exc}")
            return

        logger.info(
            f"Phân giải thành công: '{resolved.title}' | "
            f"Thời lượng: {resolved.duration or 0:.0f}s | Live: {resolved.is_live}"
        )
        self._current_stream_url = resolved.stream_url
        self.gui.hide_overlay()
        self.gui.set_status(f"Đang phát: {resolved.title}")

        # Auto-detect vertical video (9:16) for Reels, TikTok, Shorts
        is_vertical = False
        url_lower = original_url.lower()
        if any(k in url_lower for k in ("/reel/", "/reels/", "/shorts/", "tiktok.com", "douyin.com")):
            is_vertical = True
        elif resolved.height and resolved.width and resolved.height > resolved.width:
            is_vertical = True
        elif resolved.formats:
            v_fmts = [f for f in resolved.formats if f.height and f.width]
            if v_fmts:
                best_fmt = max(v_fmts, key=lambda f: (f.height or 0) * (f.width or 0))
                if best_fmt.height and best_fmt.width and best_fmt.height > best_fmt.width:
                    is_vertical = True

        if is_vertical:
            self.gui.set_pip_aspect_ratio("9:16")
        else:
            self.gui.set_pip_aspect_ratio("16:9")

        resolved_dur_ms = int((resolved.duration or 0) * 1000)
        self._resolved_duration_ms = resolved_dur_ms

        # Record start of playback in history (increments watch count cleanly once)
        self.history.record_playback_start(
            url=original_url,
            title=resolved.title,
            duration_ms=resolved_dur_ms,
            thumbnail_url=resolved.thumbnail,
        )

        # Automatically shut down local stream proxy if new stream does not require it
        if not resolved.stream_url.startswith("http://127.0.0.1:"):
            try:
                from main.stream_proxy import StreamProxyServer
                StreamProxyServer.get_instance().stop()
            except Exception:
                pass

        # Start playback via VLC
        sub_file = self.settings.get("subtitle", "file", default="")
        self.player.play(
            resolved.stream_url,
            audio_url=resolved.audio_url,
            subtitle_file=sub_file if sub_file else None,
            http_headers=resolved.http_headers,
        )

        # Apply default playback speed
        def_speed = self.settings.get("video", "default_speed", default=1.0)
        self.player.set_playback_rate(def_speed)
        self.gui.speed_var.set(f"{def_speed}x")

        # Check for saved history position to resume
        if self.settings.get("playback", "resume_playback", default=True):
            saved_pos = self.history.get_last_position(original_url)
            if saved_pos and saved_pos > 5000:
                self.root.after(200, lambda: self._perform_resume_seek(original_url, saved_pos))

    def _perform_resume_seek(self, url: str, target_ms: int, max_attempts: int = 25) -> None:
        """Reliably poll and seek to saved position once VLC stream begins playing."""
        if self._is_shutting_down or not self.player or not self._original_url:
            return

        if self._original_url != url:
            return

        state = self.player.state
        dur = self.player.get_duration()

        # Seek once VLC reports playing and duration, or when attempts exhausted
        if (state == "playing" and dur > 0) or max_attempts <= 0:
            self.player.seek_to(target_ms)
            time_str = format_timestamp(target_ms)
            self.gui.show_osd_message(f"⏱️ Tiếp tục từ {time_str}")
            logger.info(f"Đã tự động tiếp tục phát từ mốc: {time_str} ({target_ms}ms)")
        else:
            self.root.after(150, lambda: self._perform_resume_seek(url, target_ms, max_attempts - 1))

    def _apply_post_update_resume(self) -> None:
        """Seamlessly resume playback after application update."""
        if not getattr(self, "_update_resume_state", None) or self._is_shutting_down:
            return
        state = self._update_resume_state
        url = state.get("url")
        if url:
            self.gui.url_entry.delete(0, tk.END)
            self.gui.url_entry.insert(0, url)
            self.handle_play_request(url)

            # Restore audio volume and playback rate
            if "volume" in state and self.player:
                self.player.set_volume(state["volume"])
                self.gui.volume_scale.set(state["volume"])
            if "is_muted" in state and state["is_muted"] and self.player:
                self.player.set_mute(True)
                self.gui.set_mute_button_state(True)
            if "playback_rate" in state and self.player:
                rate = state["playback_rate"]
                self.player.set_playback_rate(rate)
                self.gui.speed_var.set(f"{rate}x")

            pos_ms = state.get("position_ms", 0)
            if pos_ms > 3000:
                self.root.after(300, lambda: self._perform_resume_seek(url, pos_ms))
            self.gui.show_osd_message("🚀 Đã cập nhật thành công & tiếp tục phát!")

    def get_current_playback_snapshot(self) -> Dict[str, Any]:
        """Capture complete playback snapshot for seamless resumption across updates."""
        pos = 0
        vol = 80
        muted = False
        rate = 1.0
        if self.player:
            try:
                pos = self.player.get_position()
                vol = self.player.get_volume()
                muted = self.player.is_muted()
                rate = self.player.get_playback_rate()
            except Exception:
                pass
        return {
            "url": self._original_url or self.gui.url_entry.get().strip(),
            "position_ms": pos,
            "volume": vol,
            "is_muted": muted,
            "playback_rate": rate,
            "loop_enabled": getattr(self, "_is_loop_enabled", False),
        }

    def _background_check_update(self) -> None:
        """Background thread checking GitHub releases."""
        if self._is_shutting_down:
            return
        from main.updater import check_for_updates
        info = check_for_updates()
        if info and not self._is_shutting_down:
            self.root.after(0, lambda: self._prompt_update_dialog(info))

    def _prompt_update_dialog(self, info) -> None:
        """Prompt user with update dialog."""
        if self._is_shutting_down:
            return
        ans = messagebox.askyesno(
            "Có bản cập nhật mới!",
            f"Đã có phiên bản mới: v{info.version}!\n\n"
            f"Tiêu đề: {info.title}\n"
            f"Tệp cập nhật: {info.asset_name} ({info.asset_size // 1024 // 1024} MB)\n\n"
            f"Ghi chú:\n{info.release_notes[:250]}\n\n"
            "Bạn có muốn tải về và cập nhật ngay bây giờ không?\n"
            "(Video đang xem sẽ không bị gián đoạn trong khi tải)",
            parent=self.root,
        )
        if ans:
            self._start_update_download(info)

    def _start_update_download(self, info) -> None:
        """Start downloading update in background thread while video continues playing."""
        if self._is_shutting_down:
            return
        from main.updater import download_update, apply_update_and_restart
        self.gui.show_osd_message(f"⬇️ Đang tải bản cập nhật v{info.version} ngầm...")

        def _on_progress(percent: float, downloaded: int, total: int):
            mb_down = downloaded / (1024 * 1024)
            mb_tot = total / (1024 * 1024)
            msg = f"Đang tải cập nhật v{info.version}: {percent:.1f}% ({mb_down:.1f}MB / {mb_tot:.1f}MB)"
            self.root.after(0, lambda: self.gui.set_status(msg))

        def _worker():
            zip_path = download_update(info, progress_callback=_on_progress)
            if not zip_path:
                self.root.after(0, lambda: messagebox.showerror("Lỗi cập nhật", "Tải bản cập nhật thất bại hoặc bị hủy. Vui lòng thử lại sau.", parent=self.root))
                return

            def _on_ready():
                snapshot = self.get_current_playback_snapshot()
                self.gui.show_osd_message("🚀 Đang khởi động lại để áp dụng bản cập nhật...")
                if apply_update_and_restart(zip_path, snapshot):
                    self.on_closing()
                    import os
                    threading.Timer(1.0, lambda: os._exit(0)).start()

            self.root.after(0, _on_ready)

        threading.Thread(target=_worker, daemon=True).start()

    def handle_pause_toggle(self) -> None:
        if self.player:
            was_playing = (self.player.state == "playing")
            self.player.toggle_play_pause()
            self.gui.show_osd_action("pause" if was_playing else "play")
            self.gui.set_play_pause_button_state(not was_playing)

    def handle_seek_request(self, time_ms: int) -> None:
        if self.player:
            self.player.seek_to(time_ms)
            if self.player.state == "playing":
                self.gui.set_play_pause_button_state(True)

    def handle_seek_relative(self, delta_seconds: int) -> None:
        if self.player:
            self.player.seek_relative(delta_seconds)
            self.gui.show_osd_seek(delta_seconds)

    def handle_volume_change(self, volume: int) -> None:
        if self.player:
            self.player.set_volume(volume)
            is_muted = self.player.is_muted()
            self.gui.set_mute_button_state(is_muted)
            if type(volume) in (int, float):
                self.settings.set("audio", "default_volume", int(volume))
            if type(is_muted) is bool:
                self.settings.set("audio", "is_muted", is_muted)
            self.gui.show_osd_volume(volume, is_muted)

    def handle_mute_toggle(self) -> None:
        if self.player:
            is_muted = self.player.toggle_mute()
            self.gui.set_mute_button_state(is_muted)
            if type(is_muted) is bool:
                self.settings.set("audio", "is_muted", is_muted)
            vol = self.player.get_volume()
            self.gui.show_osd_volume(vol, is_muted)

    def handle_rate_change(self, rate: float) -> None:
        if self.player:
            self.player.set_playback_rate(rate)
            self.gui.show_osd_speed(rate)

    def _on_window_focus_in(self, event=None) -> None:
        """Check clipboard immediately when user focuses the application window."""
        self._check_clipboard()

    def _check_clipboard(self) -> None:
        """Check clipboard for playable video URLs and display toast prompt."""
        if self._is_shutting_down:
            return
        if not self.settings.get("ui", "clipboard_auto_detect", default=True):
            return
        try:
            clip = self.root.clipboard_get().strip()
        except Exception:
            return

        if not clip or clip == self._last_detected_clipboard:
            return

        current_url = self.gui.url_entry.get().strip()
        if clip == current_url or clip == self._original_url:
            return

        if is_potential_video_url(clip):
            self._last_detected_clipboard = clip
            self.gui.show_clipboard_prompt(clip)

    def handle_open_history(self) -> None:
        """Open watch history modal. If already open, brings to front."""
        if hasattr(self, "_history_dialog") and self._history_dialog is not None:
            try:
                if self._history_dialog.top.winfo_exists():
                    self._history_dialog.top.lift()
                    self._history_dialog.top.focus_force()
                    return
            except Exception:
                self._history_dialog = None

        from main.history_dialog import HistoryDialog
        self._history_dialog = HistoryDialog(
            parent=self.root,
            history_mgr=self.history,
            theme_mgr=self.theme,
            on_play_video=self._on_play_from_history,
        )

    def _on_play_from_history(self, url: str, resume_pos_ms: int) -> None:
        """Handle video selected from watch history."""
        self.gui.url_entry.delete(0, tk.END)
        self.gui.url_entry.insert(0, url)
        self.handle_play_request(url)
        if resume_pos_ms > 5000:
            self.root.after(200, lambda: self._perform_resume_seek(url, resume_pos_ms))

    def handle_download_request(self, audio_only: Optional[bool] = None) -> None:
        """Handle video download request via VideoDownloader."""
        url = self.gui.url_entry.get().strip() or self._original_url
        if not url:
            messagebox.showinfo("Tải video", "Vui lòng dán hoặc nhập liên kết video trước khi tải về.")
            return

        if hasattr(self, "_active_downloader") and self._active_downloader and self._active_downloader._thread and self._active_downloader._thread.is_alive():
            if messagebox.askyesno("Đang tải video", "Đang có tiến trình tải video khác. Bạn có muốn hủy tiến trình hiện tại để tải video mới không?"):
                self._active_downloader.cancel()
            else:
                return

        # Determine download format (Video MP4 vs Audio MP3)
        if audio_only is None:
            fmt_setting = self.settings.get("download", "format", default="video")
            if fmt_setting == "audio":
                audio_only = True
            elif fmt_setting == "video":
                audio_only = False
            else:
                # "ask" mode: prompt user with a clean choice dialog
                choice = messagebox.askyesnocancel(
                    "Định dạng tải xuống",
                    "Bạn muốn tải video hay chỉ lấy âm thanh (MP3)?\n\n"
                    "• Chọn 'Yes' để tải Video đầy đủ (MP4)\n"
                    "• Chọn 'No' để chỉ tải file Âm thanh (MP3)\n"
                    "• Chọn 'Cancel' để hủy bỏ",
                    parent=self.root,
                )
                if choice is None:
                    return
                audio_only = (choice is False)

        from pathlib import Path
        from main.downloader import VideoDownloader, get_default_download_dir
        download_dir = None
        custom_dir = self.settings.get("download", "download_dir", default="")
        if custom_dir and Path(custom_dir).is_dir():
            download_dir = Path(custom_dir)
        else:
            download_dir = get_default_download_dir()

        # If user enabled "Always ask where to save before downloading"
        always_ask = self.settings.get("download", "always_ask", default=False)
        if always_ask:
            chosen = filedialog.askdirectory(
                parent=self.root,
                title="Chọn thư mục lưu file tải về",
                initialdir=str(download_dir),
            )
            if not chosen:
                return
            download_dir = Path(chosen)

        cookie_file = self.settings.get("advanced", "cookie_file", default="")
        max_height = self.settings.get("video", "max_height", default=1080)

        fmt_label = "âm thanh MP3" if audio_only else "video"
        self.gui.btn_download.configure(text="⬇ 0%", state=tk.DISABLED)
        self.gui.set_status(f"Bắt đầu tải {fmt_label} vào: {download_dir}...")

        def on_progress(info: dict):
            pct = info.get("percent", 0.0)
            spd = info.get("speed_str", "")
            sz = info.get("size_str", "")
            eta = info.get("eta_str", "")
            status_msg = f"Đang tải {pct:.1f}% ({sz} - {spd} - còn {eta})"
            self.root.after(0, lambda: self._on_download_progress(pct, status_msg))

        def on_complete(filepath: Path):
            self.root.after(0, lambda: self._on_download_completed(filepath))

        def on_error(err_msg: str):
            self.root.after(0, lambda: self._on_download_error(err_msg))

        self._active_downloader = VideoDownloader(
            url=url,
            output_dir=download_dir,
            cookie_file=cookie_file if cookie_file else None,
            max_height=max_height,
            audio_only=audio_only,
            audio_format="mp3",
            on_progress=on_progress,
            on_complete=on_complete,
            on_error=on_error,
        )
        self._active_downloader.start()

    def _on_download_progress(self, percent: float, status_msg: str) -> None:
        if not self._is_shutting_down:
            self.gui.btn_download.configure(text=f"⬇ {int(percent)}%")
            self.gui.set_status(status_msg)

    def _on_download_completed(self, filepath) -> None:
        if self._is_shutting_down:
            return
        self.gui.btn_download.configure(text="⬇ Tải về", state=tk.NORMAL)
        self.gui.set_status(f"Tải thành công: {filepath.name}")

        # Trigger Windows Toast notification if enabled
        if self.settings.get("download", "show_toast", default=True):
            from main.platform_utils import show_windows_toast
            show_windows_toast(
                title="FB Video Watcher - Đã tải xong",
                message=f"Đã lưu thành công: {filepath.name}",
            )

        if messagebox.askyesno(
            "Tải thành công",
            f"Đã lưu file thành công vào:\n{filepath}\n\nBạn có muốn mở thư mục chứa file không?",
            parent=self.root,
        ):
            import subprocess
            try:
                subprocess.Popen(f'explorer /select,"{filepath}"')
            except Exception:
                pass

    def _on_download_error(self, err_msg: str) -> None:
        if self._is_shutting_down:
            return
        self.gui.btn_download.configure(text="⬇ Tải về", state=tk.NORMAL)
        self.gui.set_status(f"Lỗi tải video: {err_msg}")
        messagebox.showerror("Lỗi tải video", err_msg)

    def _apply_cpu_optimizations(self) -> None:
        """Apply Windows EcoQoS, multimedia timer, and CPU core affinity according to settings."""
        from main.platform_utils import (
            disable_process_power_throttling,
            enable_high_precision_timer,
            apply_cpu_affinity,
        )

        perf_cfg = self.settings.get("performance", default={})
        if not isinstance(perf_cfg, dict):
            perf_cfg = {}

        # 1. High precision multimedia timer (1ms resolution)
        if perf_cfg.get("high_precision_timer", True):
            enable_high_precision_timer()

        # 2. Disable Windows EcoQoS / Efficiency Mode / Power Throttling
        if perf_cfg.get("disable_eco_qos", True):
            disable_process_power_throttling()

        # 3. CPU Core Affinity
        mode = perf_cfg.get("cpu_affinity_mode", "auto")
        apply_cpu_affinity(mode, self.sys_info)

    def handle_settings_updated(self) -> None:
        """Callback when user saves new settings."""
        # Rebuild AutoTuner and VLC args for subsequent playbacks
        self.tuner = AutoTuner(self.sys_info, self.settings.settings)
        self.vlc_args = self.tuner.build_vlc_args()

        # Re-apply CPU performance optimizations (Affinity, EcoQoS, Timer)
        self._apply_cpu_optimizations()

        # Apply updated subtitle file to player if active
        sub_file = self.settings.get("subtitle", "file", default="")
        if self.player:
            self.player.set_subtitle_file(sub_file if sub_file else None)

        if hasattr(self.gui, "update_seek_buttons"):
            self.gui.update_seek_buttons()
        if hasattr(self.gui, "rebind_shortcuts"):
            self.gui.rebind_shortcuts()

    def handle_load_subtitle(self, subtitle_path: str) -> None:
        """Attach external subtitle file dynamically to player."""
        if self.player:
            self.player.set_subtitle_file(subtitle_path)

    # --- Error & Re-resolution Strategy (§7.6) ---

    def _on_playback_error(self, message: str) -> None:
        """Marshal VLC error callback to main thread."""
        if not self._is_shutting_down:
            self.root.after(0, lambda: self._handle_playback_error_safe(message))

    def _handle_playback_error_safe(self, message: str) -> None:
        """Auto re-resolve Facebook/CDN stream URL if token expired mid-playback."""
        if self._is_shutting_down or not self.player or not self._original_url:
            self.gui.show_error(message)
            return

        current_pos = self.player.get_position()

        # If played > 5s and within retry limit -> Auto re-resolve
        if current_pos > 5000 and self._re_resolve_attempts < self._max_re_resolve_attempts:
            self._re_resolve_attempts += 1
            self.gui.set_loading(f"Stream gián đoạn. Đang tự động kết nối lại ({self._re_resolve_attempts}/3)...")

            cookie_file = self.settings.get("advanced", "cookie_file", default="")
            max_height = self.settings.get("video", "max_height", default=1080)

            future = self.executor.submit(
                resolve_facebook_url,
                url=self._original_url,
                cookie_file=cookie_file if cookie_file else None,
                max_height=max_height,
            )
            future.add_done_callback(
                lambda f: self.root.after(0, lambda: self._on_re_resolve_completed(f, current_pos))
            )
        else:
            self.gui.show_error(message)

    def _on_re_resolve_completed(self, future: concurrent.futures.Future, resume_pos: int) -> None:
        if self._is_shutting_down:
            return
        try:
            resolved = future.result()
            self._current_stream_url = resolved.stream_url
            self.gui.hide_overlay()
            self.player.play(
                resolved.stream_url,
                audio_url=resolved.audio_url,
                http_headers=resolved.http_headers,
            )
            # Delay 600ms before seek to let VLC media stream initialize
            self.root.after(600, lambda: self.player.seek_to(resume_pos))
        except Exception as exc:
            self.gui.show_error(f"Không thể kết nối lại video: {exc}")

    def _on_playback_ended(self) -> None:
        """Invoked when video finishes playing (VLC C-thread -> main thread)."""
        if not self._is_shutting_down:
            self.root.after(0, self._handle_playback_ended_safe)

    def _handle_playback_ended_safe(self) -> None:
        """Detect whether stream completed naturally or terminated prematurely (token expired)."""
        if self._is_shutting_down or not self.player or not self._original_url:
            return

        current_pos = self.player.get_position()
        duration_ms = self.player.get_duration()

        # If video ended prematurely (e.g. duration > 30s and ended > 15s early)
        if duration_ms > 30000 and current_pos < (duration_ms - 15000):
            logger.warning(
                f"Phát hiện stream bị ngắt sớm tại {current_pos // 1000}s / {duration_ms // 1000}s "
                "(có thể token Facebook/CDN đã hết hạn). Đang tự động kết nối lại..."
            )
            self._handle_playback_error_safe("Stream bị ngắt kết nối giữa chừng.")
            return

        # Check A-B repeat first
        if self._ab_point_a is not None and self.player:
            self.player.seek_to(self._ab_point_a)
            self.player.play()
            return

        # Check full video loop
        if self._is_loop_enabled and self._current_stream_url and self.player:
            logger.info("Phát hiện video kết thúc, tự động phát lặp lại (Loop Playback)")
            self.gui.show_osd_message("🔁 Tự động phát lặp lại")
            self.player.play(self._current_stream_url)
            return

        # Natural end of video
        self.gui.set_status("Đã phát xong video.")
        self.gui.set_play_pause_button_state(False)

    def handle_loop_toggle(self) -> None:
        """Toggle full video repeat on/off."""
        self._is_loop_enabled = not self._is_loop_enabled
        self.settings.set("playback", "loop_enabled", self._is_loop_enabled)
        self.settings.save()
        self.gui.set_loop_state(self._is_loop_enabled)
        self.gui.show_osd_message("🔁 Bật lặp lại video" if self._is_loop_enabled else "➡️ Tắt lặp lại video")

    def handle_ab_repeat_toggle(self) -> None:
        """Cycle A-B repeat state: Set A -> Set B -> Turn Off."""
        if not self.player:
            return

        current_pos = self.player.get_position()
        if self._ab_point_a is None:
            self._ab_point_a = current_pos
            self._ab_point_b = None
            time_a = format_timestamp(current_pos)
            self.gui.set_ab_repeat_state("A", time_a_ms=current_pos)
            self.gui.show_osd_message(f"🔁 Điểm A: {time_a}")
        elif self._ab_point_b is None:
            if current_pos <= self._ab_point_a:
                self.gui.show_osd_message("⚠️ Điểm B phải lớn hơn điểm A")
                return
            self._ab_point_b = current_pos
            time_a = format_timestamp(self._ab_point_a)
            time_b = format_timestamp(self._ab_point_b)
            self.gui.set_ab_repeat_state("AB", time_a_ms=self._ab_point_a, time_b_ms=self._ab_point_b)
            self.gui.show_osd_message(f"🔁 Lặp A-B: [{time_a} ⇄ {time_b}]")
        else:
            self._ab_point_a = None
            self._ab_point_b = None
            self.gui.set_ab_repeat_state("OFF")
            self.gui.show_osd_message("🔁 Tắt lặp đoạn A-B")

    # --- Shutdown & Position Persistence (§9.2 E) ---

    def _save_current_position(self) -> None:
        """Persist current video playback position into SQLite."""
        if self.player and self._original_url:
            pos = self.player.get_position()
            dur = self.player.get_duration()
            if pos > 3000:
                self.history.save_position(
                    url=self._original_url,
                    position_ms=pos,
                    duration_ms=dur,
                )

    def on_closing(self) -> None:
        """Handle window closing event cleanly without freezing (§9.2 E)."""
        self._is_shutting_down = True
        self._save_current_position()

        # Save last PiP dimensions if closed during PiP mode
        if getattr(self.gui, "_is_pip", False):
            w = getattr(self.gui, "_last_resized_pip_w", None) or self.gui.root.winfo_width()
            h = getattr(self.gui, "_last_resized_pip_h", None) or self.gui.root.winfo_height()
            self.gui._save_current_pip_size(w, h)

        # Save last URL from entry or active URL (§Feature 1)
        current_url = self.gui.url_entry.get().strip() or self._original_url
        if current_url:
            self.settings.set("playback", "last_url", current_url)

        # Save persistent audio volume and mute state
        if self.player:
            try:
                vol = self.player.get_volume()
                if type(vol) in (int, float):
                    self.settings.set("audio", "default_volume", int(vol))
                muted = self.player.is_muted()
                if type(muted) is bool:
                    self.settings.set("audio", "is_muted", muted)
            except Exception:
                pass

        self.settings.save()

        if self.player:
            self.player.release()

        # Shutdown worker threads
        self.executor.shutdown(wait=False, cancel_futures=True)

        # Shut down local stream proxy
        try:
            from main.stream_proxy import StreamProxyServer
            StreamProxyServer.get_instance().stop()
        except Exception:
            pass

        # Restore Windows multimedia timer resolution
        try:
            from main.platform_utils import disable_high_precision_timer
            disable_high_precision_timer()
        except Exception:
            pass

        # Destroy GUI
        if hasattr(self.gui, "destroy"):
            try:
                self.gui.destroy()
            except Exception:
                pass
        self.root.destroy()
